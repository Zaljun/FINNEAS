from flask import Flask, redirect, url_for, render_template
import os
import data_support as ds

app = Flask(__name__,)

picFolder = os.path.join('static')

app.config['UPLOAD_FOLDER'] = picFolder

homepage_stocks = ['AAPL', 'GE', 'NKE', 'TSLA', 'TMUS', 'GOOG', 'AMZN', 'SBUX', 'FB', 'MSFT']

@app.route("/")
def home():
	FinPic = os.path.join(app.config['UPLOAD_FOLDER'], 'FINNEAS2.png')
	graph = os.path.join(app.config['UPLOAD_FOLDER'], 'graph_placeholder.png')

	return render_template("index.html", user_image1 = FinPic, user_image2 = graph)

@app.route("/news")
def news():
	FinPic = os.path.join(app.config['UPLOAD_FOLDER'], 'FINNEAS2.png')
	newsRequest = {
        'size':10
    }
	data = ds.get_general_news(newsRequest)
	datadict = {
        'records':data,
        'colnames':data[0].keys()
    }

	return render_template("news.html", user_image1 = FinPic, data=datadict)

@app.route("/top_companies")
def company():
	FinPic = os.path.join(app.config['UPLOAD_FOLDER'], 'FINNEAS2.png')
	graph = os.path.join(app.config['UPLOAD_FOLDER'], 'graph_placeholder.png')
	data = []
	for symbol in homepage_stocks:
		request = {
            'symbol':symbol
        }
		price = ds.get_last_price(request)
		data.append(price)
	datadict = {
        'records':data,
        'colnames':data[0].keys()
    }

	return render_template("top.html", user_image1 = FinPic, user_image2 = graph, data=datadict)


@app.route("/Stock")
def StockTemplate():
	FinPic = os.path.join(app.config['UPLOAD_FOLDER'], 'FINNEAS2.png')
	graph = os.path.join(app.config['UPLOAD_FOLDER'], 'graph_placeholder.png')

	return render_template("Stock.html", user_image1 = FinPic, user_image2 = graph)

@app.route("/Stocknews")
def StockNews():
	FinPic = os.path.join(app.config['UPLOAD_FOLDER'], 'FINNEAS2.png')
	graph = os.path.join(app.config['UPLOAD_FOLDER'], 'graph_placeholder.png')

	return render_template("Stocknews.html", user_image1 = FinPic, user_image2 = graph)


@app.route("/Hdata")
def HistoricalData():
	FinPic = os.path.join(app.config['UPLOAD_FOLDER'], 'FINNEAS2.png')
	graph = os.path.join(app.config['UPLOAD_FOLDER'], 'graph_placeholder.png')

	return render_template("Hdata.html", user_image1 = FinPic, user_image2 = graph)

@app.route("/financials")
def financials():
	FinPic = os.path.join(app.config['UPLOAD_FOLDER'], 'FINNEAS2.png')
	graph = os.path.join(app.config['UPLOAD_FOLDER'], 'graph_placeholder.png')

	return render_template("financials.html", user_image1 = FinPic, user_image2 = graph)


@app.route("/analysis")
def analysis():
	FinPic = os.path.join(app.config['UPLOAD_FOLDER'], 'FINNEAS2.png')
	graph = os.path.join(app.config['UPLOAD_FOLDER'], 'graph_placeholder.png')

	return render_template("analysis.html", user_image1 = FinPic, user_image2 = graph)

if __name__ == "__main__":
	app.run(debug=True)