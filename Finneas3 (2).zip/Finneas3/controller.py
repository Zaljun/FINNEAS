import data_support as ds
import data_analysis as da
import datetime

HOMEPAGE_STOCKS = ['AAPL', 'GE', 'NKE', 'TSLA', 'TMUS', 'GOOG', 'AMZN', 'SBUX', 'FB', 'MSFT']
HOMEPAGE_NEWS_SIZE = 10
STOCK_NEWS_SIZE = 5
DEFAULT_HISTORIC_RANGE = 0
DEFAULT_HISTORIC_TIMESPAN = 'day'
OVERVIEW_DATA_KEYS = ['MarketCapitalization', 'EBITDA', 'PERatio', 
'BookValue', 'DividendPerShare', 'DividendYield', 'EPS', 'QuarterlyEarningsGrowthYOY', 
'QuarterlyRevenueGrowthYOY', 'TrailingPE', 'ForwardPE',
'52WeekHigh', '52WeekLow','50DayMovingAverage','ForwardAnnualDividendRate',
'ForwardAnnualDividendYield']

def stock_info(symbol):
    '''returns price and percent change compared to yesterday's closing price, to display on stock's page'''
    data = ds.get_last_price({'symbol':symbol})
    current = data['Last Price']
    today = data['Timestamp']
    yesterday = str((datetime.datetime.utcfromtimestamp(today) - datetime.timedelta(days=1)).date())+'T09:00:00-04:00'
    previous_day_request = {
        'symbol':symbol,
        'timespan':'day',
        'from':yesterday,
        'to':yesterday,
        'limit':'1'
    }
    previous = ds.get_historical(previous_day_request)
    previous = previous[0]['Close']
    change = round(current - previous, 3)
    percent_change = da.percent_change(current, previous)
    percent_change = str(round(percent_change, 3))+'%'
    today = datetime.datetime.utcfromtimestamp(today).strftime('%Y-%m-%d %H:%M:%S')

    return current, change, percent_change, today
    # if its the next day but before 9am, return the previous day's price
    # along with percentage change of previous previous day
    # and datetime 4pm


def homepage():
    # necessary??
    ''' news, top stocks'''
    pass

def news_page():
    '''
    news
    '''
    news_request = {
        'size':HOMEPAGE_NEWS_SIZE
    }
    data = ds.get_general_news(news_request)
    datadict = {
        'records':data,
        'colnames':data[0]['data'].keys()
    }

    return datadict

def top_stocks_page():
    data = []
    for symbol in HOMEPAGE_STOCKS:
        last_price, change, percent_change, datetime = stock_info(symbol)
        datadict = {
        'name':symbol,
        'price':last_price,
        'change':change,
        'percent change':percent_change,
        'last retrieved time':datetime,
        }
        data.append(datadict)

    datadict = {
        'records':data,
        'colnames':data[0].keys()
    }

    return datadict

def stock_overview_page(symbol):
    '''
    latest price, latest % change, last retrieved time, exchange, overviewdata
    minute data for the day for chart
    news
    '''
    last_price, change, percent_change, datetime = stock_info(symbol)
    # call ds.get_company_overview()
    # call ds.get_historical() of day
    # call ds.get_company_news()

    company_news_req = { #fix: make symbol map to company name
        'symbol':symbol,
        'size':STOCK_NEWS_SIZE
    }

    data = ds.get_company_news(company_news_req)

    news = {
        'records':data,
        'colnames':data[0]['data'].keys()
    }

    historical_req  = {
        'symbol':symbol,
        'timespan':DEFAULT_HISTORIC_TIMESPAN,
        'from':'2020-10-11T09:00:00-04:00',
        'to':'2020-11-11T09:00:00-04:00'
    }
    historical_data = ds.get_historical(historical_req)
    
    ################################################

    historical_data_1 = {
        'labels': [ d['Date'] for d in historical_data],
        'values': [ d['Close'] for d in historical_data]
    }
    ################################################

    overview_data = ds.get_company_overview({'symbol':symbol})
    overview_data_1 = {}

    for key,value in overview_data.items():
        if key in OVERVIEW_DATA_KEYS:
            # put spaces in key
            new_key = key
            new_val = value
            if value == 'None':
                new_val = 'N/A'

            overview_data_1[new_key] = new_val



    datadict = {
        'name':symbol,
        'price':last_price,
        'change':change,
        'percent change':percent_change,
        'last retrieved time':datetime,
        'news':news,
        'chart_data':historical_data_1,
        'overview_data':overview_data_1
    }
    
    #     'exchange':0,
    #     'overview data':0,
    #     'chart_data':0
    #     'news':0
    # }

    labels = historical_data_1['labels']
    values = historical_data_1['values']
    return datadict, labels, values

def stock_historic_page(stock):

    historical_req  = {
        'symbol':stock,
        'timespan':DEFAULT_HISTORIC_TIMESPAN,
        'from':'2019-11-11T09:00:00-04:00',
        'to':'2020-11-11T09:00:00-04:00'
    }
    data = ds.get_historical(historical_req)

    datadict = {
        'records':data[::-1],
        'colnames':data[0].keys()
    }

    return datadict

def stock_analysis_page(stock):

    historical_req  = {
        'symbol':stock,
        'timespan':DEFAULT_HISTORIC_TIMESPAN,
        'from':'2019-10-11T09:00:00-04:00',
        'to':'2020-11-11T09:00:00-04:00'
    }

    historical_data = ds.get_historical(historical_req)
    data = da.fit_line(historical_data)

    labels = list(data['Date'].values)
    prices = list(data['price'].values)
    line = list(data['line'].values)

    return labels, prices, line

def stock_fs_page():
    pass


def stock_line_graph(stock):
    historical_req  = {
        'symbol':'MSFT',
        'timespan':'day', 
        'limit': '10',
        'from':'2019-11-11T09:00:00-04:00',
        'to':'2020-11-11T09:00:00-04:00'
    }
    histdata = ds.get_historical(historical_req)
    plotdata = da.fit_line(histdata)
    return plotdata
'''
page renders default values and then lets the user tweak, probably need js for this?
functions for buttons...
- overviewpage: , expand graph? change range? zoom in out?
- historic: change timeframe and granularity
- stockanalysis: choose analisis, timeframe, granularity
- financial statements: choose timeframe
'''




if __name__ == '__main__':
    # current, change, percent, today = stock_info('TSLA')
    # print(current)
    data, labels, values = stock_overview_page('AAPL')
    print(data['chart_data'])