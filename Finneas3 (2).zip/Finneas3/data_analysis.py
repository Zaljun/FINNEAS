import pandas as pd
import numpy as np

def percent_change(current,previous):
    return 100*(current-previous)/previous

def fit_line(data):
    df = pd.DataFrame(data)
    
    y_values = df['Close']
    #creating equally spaced values for the x axis instead of using the dates 
    x_values = np.linspace(0,1,len(y_values))

    # compute the equation of the line
    poly_degree = 2
    coeffs = np.polyfit(x_values, y_values, poly_degree)
    poly_eqn = np.poly1d(coeffs)

    # compute the y values for the line 
    y_hat = poly_eqn(x_values)

    #return new dataframe with columns date, price and line
    new_df = pd.DataFrame(df['Date'].values, columns=['Date'])
    new_df['price'] = y_values
    new_df['line'] = y_hat
    return new_df

def k_line(data):
    pass

if __name__ == '__main__':

    import matplotlib.pyplot as plt
    import data_support as ds

    historical_req  = {
        'symbol':'TSLA',
        'timespan':'day', 
        'limit': '10',
        'from':'2019-10-11T09:00:00-04:00',
        'to':'2020-11-11T09:00:00-04:00'
    }

    historical_data = ds.get_historical(historical_req)


    plot_data = fit_line(historical_data)
    print(plot_data)
    plt.figure(figsize=(12,8))
    plt.plot(plot_data['Date'], plot_data['price'], "ro")
    plt.plot(plot_data['Date'],plot_data['line'])
    plt.title(historical_req['symbol'])
    plt.ylabel('Price')
    plt.xlabel('Date')
    plt.show()

