from flask import Flask, redirect, url_for, render_template, request
import os
import controller

app = Flask(__name__)

picFolder = os.path.join('/static')

app.config['UPLOAD_FOLDER'] = picFolder

@app.route("/", methods=['GET', 'POST'])
def home():
    FinPic = os.path.join(app.config['UPLOAD_FOLDER'], 'FINNEAS3.png')
    homepic = os.path.join(app.config['UPLOAD_FOLDER'], 'finneasHomePic.png')

    if request.method == "POST":
        name = request.form.get("symbol")
        name = name.upper()
        return redirect(url_for("stocks", stock=name)) 
    return render_template("index.html", user_image1 = FinPic, user_image2 = homepic)

@app.route("/news")
def news():
    FinPic = os.path.join(app.config['UPLOAD_FOLDER'], 'FINNEAS3.png')
    data = controller.news_page()

    return render_template("news.html", user_image1 = FinPic, data=data)

@app.route("/top_companies")
def company():
    FinPic = os.path.join(app.config['UPLOAD_FOLDER'], 'FINNEAS3.png')
    graph = os.path.join(app.config['UPLOAD_FOLDER'], 'graph_placeholder.png')
    
    data = controller.top_stocks_page()

    return render_template("top.html", user_image1 = FinPic, user_image2 = graph, data=data)

@app.route("/stocks/<stock>/overview")
def stocks(stock):
    FinPic = os.path.join(app.config['UPLOAD_FOLDER'], 'FINNEAS3.png')
    graph = os.path.join(app.config['UPLOAD_FOLDER'], 'graph_placeholder.png')

    data, labels, values = controller.stock_overview_page(stock)
    
    return render_template("stock.html", user_image1 = FinPic, user_image2 = graph, data=data, stock=stock, labels=labels, values=values)

@app.route("/stocks/<stock>/historical")
def historical(stock):
    FinPic = os.path.join(app.config['UPLOAD_FOLDER'], 'FINNEAS3.png')
    graph = os.path.join(app.config['UPLOAD_FOLDER'], 'graph_placeholder.png')

    data = controller.stock_historic_page(stock)
    return render_template("historical.html", user_image1 = FinPic, user_image2 = graph, data=data, stock=stock)

@app.route("/stocks/<stock>/financials")
def financials(stock):
    FinPic = os.path.join(app.config['UPLOAD_FOLDER'], 'FINNEAS3.png')
    graph = os.path.join(app.config['UPLOAD_FOLDER'], 'graph_placeholder.png')

    return render_template("financials.html", user_image1 = FinPic, user_image2 = graph, stock=stock)


@app.route("/stocks/<stock>/analysis")
def analysis(stock):
    FinPic = os.path.join(app.config['UPLOAD_FOLDER'], 'FINNEAS3.png')
    graph = os.path.join(app.config['UPLOAD_FOLDER'], 'graph_placeholder.png')

    labels, prices, line = controller.stock_analysis_page(stock)
    return render_template("analysis.html", user_image1 = FinPic, user_image2 = graph, stock=stock, labels=labels, values1=prices, values2=line)


@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html')
 
 
@app.errorhandler(500)
def internal_server_error(e):
    return render_template('500.html')
 

if __name__ == "__main__":
    app.run(debug=True)


# erase financials page and put profile page instead?
# fix datetimes for last price display, historic data and graphs
# fix formatting and chart design































# fix datetime handling
    # make default data
    # fix formatting 
    # timeseries from chart.js website
    # fix utc time
    # no after hours pricing, latest time of price retrieved must be 4pm of a weekday

# finish filling out data on stock overview page (and maybe financials page/ might drop)

# default values for timeframes
# make chart callbacks for drop down menus and submit buttons
# drop down calendar to choose a date frame in historical page and analysis page

# data validation for search bar input and message for invalid input (might need big list or database)

# add one more function to data analysis

# add try/except blocks

# API calls, if we ran out of calls then just render previous price

# news: mapping of stocks to names of companies 




'''



Company profile page:
Name
AssetType
Description
Exchange
CUrrency
Country
Sector
Industry
Address
FullTimeEmployees
FiscalYearEnd
LatestQuarter




'''

