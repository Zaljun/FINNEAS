from flask import Flask, redirect, url_for, render_template
import os

app = Flask(__name__,)

picFolder = os.path.join('static')

app.config['UPLOAD_FOLDER'] = picFolder


@app.route("/")
def home():
	FinPic = os.path.join(app.config['UPLOAD_FOLDER'], 'FINNEAS2.png')
	graph = os.path.join(app.config['UPLOAD_FOLDER'], 'graph_placeholder.png')

	return render_template("index.html", user_image1 = FinPic, user_image2 = graph)

@app.route("/news")
def news():
	FinPic = os.path.join(app.config['UPLOAD_FOLDER'], 'FINNEAS2.png')

	return render_template("news.html", user_image1 = FinPic)

@app.route("/top_companies")
def company():
	FinPic = os.path.join(app.config['UPLOAD_FOLDER'], 'FINNEAS2.png')
	graph = os.path.join(app.config['UPLOAD_FOLDER'], 'graph_placeholder.png')

	return render_template("top.html", user_image1 = FinPic, user_image2 = graph)


@app.route("/Stock")
def StockTemplate():
	FinPic = os.path.join(app.config['UPLOAD_FOLDER'], 'FINNEAS2.png')
	graph = os.path.join(app.config['UPLOAD_FOLDER'], 'graph_placeholder.png')

	return render_template("Stock.html", user_image1 = FinPic, user_image2 = graph)



@app.route("/analysis")
def analysis():
	FinPic = os.path.join(app.config['UPLOAD_FOLDER'], 'FINNEAS2.png')
	graph = os.path.join(app.config['UPLOAD_FOLDER'], 'graph_placeholder.png')

	return render_template("analysis.html", user_image1 = FinPic, user_image2 = graph)

if __name__ == "__main__":
	app.run(debug=True)